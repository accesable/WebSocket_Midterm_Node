# WebSocket Using Socket.io
521H0491 - Trần Nhựt Anh \
521H0044 - Hồ Minh Chí Tân \
[Link Youtube Report](https://www.youtube.com/watch?v=KDGRPSiv1Ew)
```cmd
//Client code to start react js
cd client
npm install
npm start
//Server code to start Node js
cd server
npm install
npm run start
```